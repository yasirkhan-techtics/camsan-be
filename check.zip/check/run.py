"""
Runner script to perform symbol detection with custom parameters
"""

from utils.Tag_and_icon_search_gpu import detect_and_export

# ============================================================================
# CONFIGURATION PARAMETERS
# ============================================================================

# Input/Output paths
template_path = "my_templates.pkl"
search_image_path = "page_9.png"
output_path = "output"

# Detection thresholds
general_threshold = 0.7
tag_threshold = 0.7
icon_threshold = 0.5

# Scale parameters (None = use defaults: [0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3])
tag_scales = [0.8, 0.9, 1.0, 1.1, 1.2]
icon_scales = [0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3]
# Rotation parameters (None = use defaults: [0, 15, 30, ..., 345])
tag_rotations =  [0, 30, 60, 90]
icon_rotations =  list(range(0, 360, 15))

# NMS threshold (overlap threshold for duplicate removal)
nms_threshold = 0.3

# Processing parameters
use_gpu = True
num_workers = 2  # Number of parallel workers (adjust based on your CPU cores)

# ============================================================================
# RUN DETECTION
# ============================================================================

if __name__ == "__main__":
    print("="*70)
    print("SYMBOL DETECTION - Starting...")
    print("="*70)
    print(f"Template file: {template_path}")
    print(f"Search image: {search_image_path}")
    print(f"Output folder: {output_path}")
    print(f"Icon threshold: {icon_threshold}")
    print(f"Tag threshold: {tag_threshold}")
    print(f"GPU enabled: {use_gpu}")
    print(f"Workers: {num_workers}")
    print("="*70 + "\n")
    
    # Run detection
    results = detect_and_export(
        template_path=template_path,
        search_image_path=search_image_path,
        output_folder=output_path,
        threshold=general_threshold,
        tag_threshold=tag_threshold,
        icon_threshold=icon_threshold,
        tag_scales=tag_scales,
        icon_scales=icon_scales,
        tag_rotations=tag_rotations,
        icon_rotations=icon_rotations,
        nms_threshold=nms_threshold,
        use_gpu=use_gpu,
        num_workers=num_workers
    )
    
    # Print summary
    print("\n" + "="*70)
    print("DETECTION COMPLETE - SUMMARY")
    print("="*70)
    
    total_detections = 0
    for icon_name, detections in results['results_by_icon'].items():
        icon_count = sum(1 for d in detections if d.template_type == 'icon')
        tag_count = sum(1 for d in detections if d.template_type == 'tag')
        total_detections += len(detections)
        
        print(f"\nIcon Group: '{icon_name}'")
        print(f"  Total detections: {len(detections)}")
        print(f"  Icons: {icon_count}")
        print(f"  Tags: {tag_count}")
    
    print(f"\n{'='*70}")
    print(f"OVERALL TOTAL: {total_detections} detections")
    print(f"Output saved to: {output_path}/")
    print("="*70)