"""
GPU-Accelerated Symbol Detector - Detection Only
Reads templates from PKL and performs detection with CSV export
"""

import cv2
import numpy as np
from typing import List, Tuple, Dict
import pickle
import os
import pandas as pd
from pathlib import Path
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
import multiprocessing as mp
import time


@dataclass
class Detection:
    """Store detection information"""
    bbox: Tuple[int, int, int, int]  # (x, y, w, h)
    confidence: float
    scale: float
    rotation: float
    center: Tuple[int, int]
    tag_name: str = None
    template_type: str = None
    icon_group: str = None


@dataclass
class TemplateGroup:
    """Store a group of templates (one icon + multiple tags)"""
    icon_name: str
    icon_template: np.ndarray
    icon_template_gray: np.ndarray
    tags: List[Tuple[str, np.ndarray, np.ndarray]]


class SymbolDetector:
    """
    Load templates and perform detection with CSV export per icon group
    """
    
    def __init__(self, 
                 scales: List[float] = None,
                 rotations: List[float] = None,
                 tag_scales: List[float] = None,
                 tag_rotations: List[float] = None,
                 icon_scales: List[float] = None,
                 icon_rotations: List[float] = None,
                 threshold: float = 0.7,
                 tag_threshold: float = None,
                 icon_threshold: float = None,
                 nms_threshold: float = 0.3,
                 use_gpu: bool = True,
                 num_workers: int = None):
        """Initialize the detector"""
        self.scales = scales or [0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3]
        self.rotations = rotations or list(range(0, 360, 15))
        
        self.tag_scales = tag_scales if tag_scales is not None else self.scales
        self.tag_rotations = tag_rotations if tag_rotations is not None else self.rotations
        self.icon_scales = icon_scales if icon_scales is not None else self.scales
        self.icon_rotations = icon_rotations if icon_rotations is not None else self.rotations
        
        self.threshold = threshold
        self.tag_threshold = tag_threshold if tag_threshold is not None else threshold
        self.icon_threshold = icon_threshold if icon_threshold is not None else threshold
        self.nms_threshold = nms_threshold
        
        self.template_groups = []
        
        # GPU settings
        self.use_gpu = use_gpu and cv2.cuda.getCudaEnabledDeviceCount() > 0
        
        print("\n" + "="*70)
        print("SYSTEM CONFIGURATION")
        print("="*70)
        if self.use_gpu:
            print(f"✓ GPU acceleration: ENABLED")
            print(f"  CUDA devices found: {cv2.cuda.getCudaEnabledDeviceCount()}")
        else:
            print(f"✗ GPU acceleration: DISABLED (running on CPU)")
        
        # Parallel processing
        self.num_workers = num_workers or max(1, mp.cpu_count() - 1)
        print(f"✓ Parallel processing: ENABLED")
        print(f"  Workers: {self.num_workers}")
        print(f"  CPU cores available: {mp.cpu_count()}")
        print("="*70 + "\n")
    
    def load_templates(self, template_path: str):
        """Load templates from disk"""
        import sys
        
        # Custom unpickler to handle module path changes
        class CustomUnpickler(pickle.Unpickler):
            def find_class(self, module, name):
                # Redirect old module paths to current module
                if 'utils.' in module or module.startswith('Tag_and_icon_search'):
                    module = '__main__'
                return super().find_class(module, name)
        
        with open(template_path, 'rb') as f:
            try:
                data = CustomUnpickler(f).load()
            except Exception as e:
                print(f"Warning: Custom unpickler failed, trying standard pickle...")
                f.seek(0)
                data = pickle.load(f)
        
        self.template_groups = data['template_groups']
        print(f"✓ Loaded {len(self.template_groups)} template groups from: {template_path}")
        for group in self.template_groups:
            print(f"  - Icon '{group.icon_name}' with {len(group.tags)} tags")
    
    def rotate_image(self, image: np.ndarray, angle: float) -> Tuple[np.ndarray, float]:
        """Rotate image by given angle"""
        h, w = image.shape[:2]
        center = (w // 2, h // 2)
        
        M = cv2.getRotationMatrix2D(center, angle, 1.0)
        
        cos = np.abs(M[0, 0])
        sin = np.abs(M[0, 1])
        new_w = int((h * sin) + (w * cos))
        new_h = int((h * cos) + (w * sin))
        
        M[0, 2] += (new_w / 2) - center[0]
        M[1, 2] += (new_h / 2) - center[1]
        
        rotated = cv2.warpAffine(image, M, (new_w, new_h), 
                                 borderMode=cv2.BORDER_CONSTANT,
                                 borderValue=(255, 255, 255))
        
        return rotated, 1.0
    
    def gpu_template_match(self, image_gray: np.ndarray, template: np.ndarray) -> np.ndarray:
        """GPU-accelerated template matching"""
        if self.use_gpu:
            try:
                gpu_image = cv2.cuda_GpuMat()
                gpu_template = cv2.cuda_GpuMat()
                gpu_image.upload(image_gray)
                gpu_template.upload(template)
                
                matcher = cv2.cuda.createTemplateMatching(cv2.CV_8UC1, cv2.TM_CCOEFF_NORMED)
                gpu_result = matcher.match(gpu_image, gpu_template)
                result = gpu_result.download()
                return result
            except Exception as e:
                return cv2.matchTemplate(image_gray, template, cv2.TM_CCOEFF_NORMED)
        else:
            return cv2.matchTemplate(image_gray, template, cv2.TM_CCOEFF_NORMED)
    
    def process_single_transform(self, args):
        """Process a single scale-rotation combination"""
        image_gray, template_gray, scale, rotation, threshold, name, ttype, icon_group, h_img, w_img = args
        
        detections = []
        
        h_t, w_t = template_gray.shape
        new_w = int(w_t * scale)
        new_h = int(h_t * scale)
        
        if new_w < 10 or new_h < 10 or new_w > w_img or new_h > h_img:
            return detections
        
        resized_template = cv2.resize(template_gray, (new_w, new_h))
        rotated_template, _ = self.rotate_image(resized_template, rotation)
        
        if rotated_template.shape[0] > h_img or rotated_template.shape[1] > w_img:
            return detections
        
        result = self.gpu_template_match(image_gray, rotated_template)
        
        if result is None:
            return detections
        
        locations = np.where(result >= threshold)
        
        for pt in zip(*locations[::-1]):
            x, y = pt
            w, h = rotated_template.shape[1], rotated_template.shape[0]
            confidence = result[y, x]
            center = (x + w // 2, y + h // 2)
            
            detection = Detection(
                bbox=(x, y, w, h),
                confidence=float(confidence),
                scale=scale,
                rotation=rotation,
                center=center,
                tag_name=name,
                template_type=ttype,
                icon_group=icon_group
            )
            detections.append(detection)
        
        return detections
    
    def non_max_suppression(self, detections: List[Detection]) -> List[Detection]:
        """Apply non-maximum suppression"""
        if len(detections) == 0:
            return []
        
        detections = sorted(detections, key=lambda x: x.confidence, reverse=True)
        keep = []
        
        while len(detections) > 0:
            current = detections[0]
            keep.append(current)
            detections = detections[1:]
            
            filtered = []
            for det in detections:
                iou = self.calculate_iou(current.bbox, det.bbox)
                if iou < self.nms_threshold:
                    filtered.append(det)
            
            detections = filtered
        
        return keep
    
    def calculate_iou(self, bbox1: Tuple[int, int, int, int], 
                     bbox2: Tuple[int, int, int, int]) -> float:
        """Calculate IoU"""
        x1, y1, w1, h1 = bbox1
        x2, y2, w2, h2 = bbox2
        
        xi1 = max(x1, x2)
        yi1 = max(y1, y2)
        xi2 = min(x1 + w1, x2 + w2)
        yi2 = min(y1 + h1, y2 + h2)
        
        inter_area = max(0, xi2 - xi1) * max(0, yi2 - yi1)
        
        box1_area = w1 * h1
        box2_area = w2 * h2
        union_area = box1_area + box2_area - inter_area
        
        if union_area == 0:
            return 0
        
        return inter_area / union_area
    
    def detect_symbols(self, search_image_path: str) -> Dict[str, List[Detection]]:
        """
        Detect symbols for all icon groups
        Returns dictionary: {icon_name: [detections]}
        """
        image = cv2.imread(search_image_path)
        if image is None:
            raise ValueError(f"Could not load image from {search_image_path}")
        
        image_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        h_img, w_img = image_gray.shape
        
        print(f"\n{'='*70}")
        print(f"DETECTION STARTED")
        print(f"{'='*70}")
        print(f"Image size: {w_img}x{h_img} pixels")
        print(f"Total icon groups to process: {len(self.template_groups)}")
        print(f"{'='*70}\n")
        
        results_by_icon = {}
        overall_start_time = time.time()
        
        for group_idx, group in enumerate(self.template_groups, 1):
            group_start_time = time.time()
            
            print(f"\n{'─'*70}")
            print(f"[{group_idx}/{len(self.template_groups)}] Processing Icon Group: '{group.icon_name}'")
            print(f"{'─'*70}")
            
            group_detections = []
            
            # Process icon
            print(f"  → Searching for ICON '{group.icon_name}'...")
            icon_threshold = self.icon_threshold
            icon_scales = self.icon_scales
            icon_rotations = self.icon_rotations
            
            tasks = []
            for scale in icon_scales:
                for rotation in icon_rotations:
                    tasks.append((
                        image_gray, group.icon_template_gray, scale, rotation,
                        icon_threshold, group.icon_name, 'icon', group.icon_name, h_img, w_img
                    ))
            
            print(f"    • Testing {len(icon_scales)} scales × {len(icon_rotations)} rotations = {len(tasks)} variations")
            
            icon_start = time.time()
            with ThreadPoolExecutor(max_workers=self.num_workers) as executor:
                results = list(executor.map(self.process_single_transform, tasks))
                raw_icon_detections = sum(len(result) for result in results)
                for result in results:
                    group_detections.extend(result)
            
            icon_elapsed = time.time() - icon_start
            print(f"    • Raw icon detections: {raw_icon_detections} (took {icon_elapsed:.1f}s)")
            
            # Process tags
            if len(group.tags) > 0:
                print(f"  → Searching for TAGS ({len(group.tags)} tag types)...")
                
                for tag_idx, (tag_name, tag_template, tag_template_gray) in enumerate(group.tags, 1):
                    print(f"    [{tag_idx}/{len(group.tags)}] Tag: '{tag_name}'")
                    tag_threshold = self.tag_threshold
                    tag_scales = self.tag_scales
                    tag_rotations = self.tag_rotations
                    
                    tasks = []
                    for scale in tag_scales:
                        for rotation in tag_rotations:
                            tasks.append((
                                image_gray, tag_template_gray, scale, rotation,
                                tag_threshold, tag_name, 'tag', group.icon_name, h_img, w_img
                            ))
                    
                    print(f"        • Testing {len(tag_scales)} scales × {len(tag_rotations)} rotations = {len(tasks)} variations")
                    
                    tag_start = time.time()
                    with ThreadPoolExecutor(max_workers=self.num_workers) as executor:
                        results = list(executor.map(self.process_single_transform, tasks))
                        raw_tag_detections = sum(len(result) for result in results)
                        for result in results:
                            group_detections.extend(result)
                    
                    tag_elapsed = time.time() - tag_start
                    print(f"        • Raw tag detections: {raw_tag_detections} (took {tag_elapsed:.1f}s)")
            else:
                print(f"  → No tags defined for this icon group")
            
            # Apply NMS for this group
            print(f"  → Applying Non-Maximum Suppression...")
            print(f"    • Before NMS: {len(group_detections)} detections")
            filtered = self.non_max_suppression(group_detections)
            print(f"    • After NMS: {len(filtered)} detections")
            
            results_by_icon[group.icon_name] = filtered
            
            # Count by type
            icon_count = sum(1 for d in filtered if d.template_type == 'icon')
            tag_count = sum(1 for d in filtered if d.template_type == 'tag')
            
            group_elapsed = time.time() - group_start_time
            print(f"  ✓ Final results for '{group.icon_name}':")
            print(f"    • Icons: {icon_count}")
            print(f"    • Tags: {tag_count}")
            print(f"    • Total: {len(filtered)}")
            print(f"    • Time: {group_elapsed:.1f}s")
            
            # Estimate remaining time
            if group_idx < len(self.template_groups):
                avg_time_per_group = (time.time() - overall_start_time) / group_idx
                remaining_groups = len(self.template_groups) - group_idx
                est_remaining = avg_time_per_group * remaining_groups
                print(f"    • Estimated time remaining: {est_remaining:.0f}s ({est_remaining/60:.1f}m)")
        
        total_elapsed = time.time() - overall_start_time
        print(f"\n{'='*70}")
        print(f"DETECTION COMPLETED")
        print(f"{'='*70}")
        total_all = sum(len(dets) for dets in results_by_icon.values())
        print(f"Grand total: {total_all} detections across all icon groups")
        print(f"Total time: {total_elapsed:.1f}s ({total_elapsed/60:.1f}m)")
        print(f"{'='*70}\n")
        
        return results_by_icon
    
    def draw_detections(self, image: np.ndarray, detections: List[Detection]) -> np.ndarray:
        """Draw bounding boxes"""
        result = image.copy()
        
        img_height, img_width = image.shape[:2]
        line_thickness = max(1, int((img_height + img_width) / 2000))  # Reduced thickness by half
        
        tag_counter = {}
        icon_counter = {}
        
        for det in detections:
            x, y, w, h = det.bbox
            
            if det.template_type == 'tag':
                color = (255, 0, 0)  # Blue for tags
                if det.tag_name not in tag_counter:
                    tag_counter[det.tag_name] = 0
                tag_counter[det.tag_name] += 1
                label = f"{det.tag_name}-{tag_counter[det.tag_name]} ({det.confidence:.2f})"
            else:
                color = (0, 255, 0)  # Green for icons
                icon_name = det.tag_name or 'icon'
                if icon_name not in icon_counter:
                    icon_counter[icon_name] = 0
                icon_counter[icon_name] += 1
                label = f"{icon_name}-{icon_counter[icon_name]} ({det.confidence:.2f})"
            
            # Draw bounding box
            overlay = result.copy()
            alpha = 0.35
            cv2.rectangle(overlay, (x, y), (x + w, y + h), color, line_thickness)
            cv2.addWeighted(overlay, alpha, result, 1 - alpha, 0, result)
            
            # Draw text label
            font = cv2.FONT_HERSHEY_SIMPLEX
            font_scale = 0.5  # Slightly smaller font
            font_thickness = max(1, line_thickness)
            (text_w, text_h), baseline = cv2.getTextSize(label, font, font_scale, font_thickness)
            
            text_x = x
            text_y = y - text_h - baseline - 5
            if text_y < 0:
                text_y = y + h + text_h + baseline + 5
            
            # Draw text background
            overlay = result.copy()
            cv2.rectangle(overlay, (text_x, text_y), 
                         (text_x + text_w + 4, text_y + text_h + baseline + 4),
                         color, -1)
            cv2.addWeighted(overlay, alpha, result, 1 - alpha, 0, result)
            
            # Draw text in RED
            cv2.putText(result, label, (text_x + 2, text_y + text_h + 2),
                       font, font_scale, (0, 0, 255), font_thickness)  # Red text (BGR format)
        
        return result
    
    def export_to_csv(self, detections: List[Detection], output_path: str):
        """Export detections to CSV file"""
        data = []
        for idx, det in enumerate(detections):
            x, y, w, h = det.bbox
            cx, cy = det.center
            
            data.append({
                'Symbol_ID': idx + 1,
                'BBox_X': int(x),
                'BBox_Y': int(y),
                'BBox_Width': int(w),
                'BBox_Height': int(h),
                'Center_X': int(cx),
                'Center_Y': int(cy),
                'Confidence': float(det.confidence),
                'Scale': float(det.scale),
                'Rotation': int(det.rotation),
                'Tag_Name': det.tag_name,
                'Template_Type': det.template_type,
                'Icon_Group': det.icon_group
            })
        
        df = pd.DataFrame(data)
        df.to_csv(output_path, index=False)
        print(f"  ✓ CSV exported: {output_path} ({len(df)} detections)")
        return df
    
    def save_results(self, search_image_path: str, results_by_icon: Dict[str, List[Detection]], 
                    output_folder: str = None):
        """Save results (images and CSVs) for each icon group"""
        if output_folder is None:
            image_dir = os.path.dirname(search_image_path) or '.'
            output_folder = os.path.join(image_dir, 'output')
        
        os.makedirs(output_folder, exist_ok=True)
        
        image = cv2.imread(search_image_path)
        base_name = Path(search_image_path).stem
        
        print("\n" + "="*70)
        print("SAVING RESULTS")
        print("="*70)
        
        for icon_name, detections in results_by_icon.items():
            # Draw detections
            result_image = self.draw_detections(image.copy(), detections)
            
            # Save image
            image_filename = f"{base_name}_{icon_name}_detected.jpg"
            image_path = os.path.join(output_folder, image_filename)
            cv2.imwrite(image_path, result_image)
            print(f"\n✓ Icon group: '{icon_name}'")
            print(f"  Image saved: {image_path}")
            
            # Save CSV
            csv_filename = f"{base_name}_{icon_name}.csv"
            csv_path = os.path.join(output_folder, csv_filename)
            self.export_to_csv(detections, csv_path)
        
        print("="*70 + "\n")


def detect_and_export(template_path: str, 
                     search_image_path: str,
                     output_folder: str = None,
                     threshold: float = 0.7,
                     tag_threshold: float = None,
                     icon_threshold: float = None,
                     tag_scales: List[float] = None,
                     icon_scales: List[float] = None,
                     tag_rotations: List[float] = None,
                     icon_rotations: List[float] = None,
                     nms_threshold: float = 0.3,
                     use_gpu: bool = True,
                     num_workers: int = None):
    """
    Load templates, detect symbols, and export results
    
    Args:
        template_path: Path to templates.pkl file
        search_image_path: Path to image to search
        output_folder: Folder to save results (default: ./output)
        threshold: General detection threshold (0-1)
        tag_threshold: Threshold for tags (defaults to threshold)
        icon_threshold: Threshold for icons (defaults to threshold)
        tag_scales: List of scales for tag detection
        icon_scales: List of scales for icon detection
        tag_rotations: List of rotations for tag detection (degrees)
        icon_rotations: List of rotations for icon detection (degrees)
        nms_threshold: Non-maximum suppression threshold
        use_gpu: Enable GPU acceleration
        num_workers: Number of parallel workers
    
    Returns:
        Dictionary with results per icon group
    """
    detector = SymbolDetector(
        threshold=threshold,
        tag_threshold=tag_threshold,
        icon_threshold=icon_threshold,
        tag_scales=tag_scales,
        icon_scales=icon_scales,
        tag_rotations=tag_rotations,
        icon_rotations=icon_rotations,
        nms_threshold=nms_threshold,
        use_gpu=use_gpu,
        num_workers=num_workers
    )
    
    detector.load_templates(template_path)
    results_by_icon = detector.detect_symbols(search_image_path)
    detector.save_results(search_image_path, results_by_icon, output_folder)
    
    return {
        'results_by_icon': results_by_icon,
        'detector': detector
    }